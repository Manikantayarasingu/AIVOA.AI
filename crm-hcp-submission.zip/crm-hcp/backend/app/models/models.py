from sqlalchemy import Column, Integer, String, Text, DateTime, Float, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.db.database import Base


class InteractionType(str, enum.Enum):
    VISIT = "visit"
    CALL = "call"
    EMAIL = "email"
    CONFERENCE = "conference"
    WEBINAR = "webinar"


class SentimentType(str, enum.Enum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"


class HCP(Base):
    __tablename__ = "hcps"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    specialty = Column(String(255))
    hospital = Column(String(255))
    email = Column(String(255), unique=True)
    phone = Column(String(50))
    territory = Column(String(100))
    engagement_score = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    interactions = relationship("Interaction", back_populates="hcp")


class Interaction(Base):
    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True)
    hcp_id = Column(Integer, ForeignKey("hcps.id"), nullable=False)
    rep_id = Column(String(100), nullable=False, default="rep_001")
    interaction_type = Column(Enum(InteractionType), default=InteractionType.VISIT)
    date = Column(DateTime(timezone=True), server_default=func.now())
    duration_minutes = Column(Integer, default=30)
    products_discussed = Column(Text)  # comma-separated
    notes = Column(Text)
    ai_summary = Column(Text)
    sentiment = Column(Enum(SentimentType), default=SentimentType.NEUTRAL)
    follow_up_required = Column(String(500))
    follow_up_date = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    hcp = relationship("HCP", back_populates="interactions")


class FollowUp(Base):
    __tablename__ = "followups"

    id = Column(Integer, primary_key=True, index=True)
    interaction_id = Column(Integer, ForeignKey("interactions.id"))
    hcp_id = Column(Integer, ForeignKey("hcps.id"))
    title = Column(String(500))
    description = Column(Text)
    due_date = Column(DateTime(timezone=True))
    completed = Column(String(10), default="false")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
