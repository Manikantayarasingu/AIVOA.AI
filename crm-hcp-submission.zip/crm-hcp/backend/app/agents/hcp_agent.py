"""
LangGraph Agent for the HCP CRM Module.
Uses gemma2-9b-it via Groq for all AI operations.
"""
import json
from typing import Annotated, TypedDict, Sequence, Optional
from datetime import datetime

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from sqlalchemy.orm import Session

from app.config import settings
from app.tools.hcp_tools import ALL_TOOLS
from app.models.models import HCP, Interaction, FollowUp, SentimentType, InteractionType


SYSTEM_PROMPT = """You are an intelligent CRM assistant for pharmaceutical field representatives.
You help log, edit, and analyze interactions with Healthcare Professionals (HCPs).

You have access to these tools:
1. log_interaction - Log a new HCP interaction with AI-powered summarization
2. edit_interaction - Edit an existing interaction record
3. get_hcp_profile - Retrieve full HCP profile and history
4. schedule_followup - Schedule follow-up tasks for HCPs
5. analyze_engagement - Analyze HCP engagement trends and get AI recommendations

Always be professional, precise, and helpful. When logging interactions:
- Extract key entities: products discussed, HCP concerns, commitments made
- Assess sentiment from the notes
- Suggest follow-up actions when appropriate

Respond in a clear, structured way. For tool calls, use the exact tool names provided."""


class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], lambda x, y: x + y]
    hcp_id: Optional[int]
    interaction_id: Optional[int]


def create_agent(db: Session):
    """Create a LangGraph agent with DB session closure for tool execution."""
    
    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0.1,
        max_tokens=2048,
    )
    
    llm_with_tools = llm.bind_tools(ALL_TOOLS)

    def call_model(state: AgentState):
        messages = state["messages"]
        if not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=SYSTEM_PROMPT)] + list(messages)
        response = llm_with_tools.invoke(messages)
        return {"messages": [response]}

    def execute_tools(state: AgentState):
        """Execute tool calls and handle DB operations."""
        last_message = state["messages"][-1]
        tool_results = []

        for tool_call in last_message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]
            tool_call_id = tool_call["id"]

            try:
                result = _execute_tool_with_db(tool_name, tool_args, db)
                tool_results.append(
                    ToolMessage(content=json.dumps(result), tool_call_id=tool_call_id)
                )
            except Exception as e:
                tool_results.append(
                    ToolMessage(
                        content=json.dumps({"error": str(e)}),
                        tool_call_id=tool_call_id
                    )
                )

        return {"messages": tool_results}

    def should_continue(state: AgentState):
        last_message = state["messages"][-1]
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    graph = StateGraph(AgentState)
    graph.add_node("agent", call_model)
    graph.add_node("tools", execute_tools)
    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
    graph.add_edge("tools", "agent")

    return graph.compile()


def _execute_tool_with_db(tool_name: str, args: dict, db: Session) -> dict:
    """Execute a tool with real DB operations."""
    
    if tool_name == "log_interaction":
        return _log_interaction_db(args, db)
    elif tool_name == "edit_interaction":
        return _edit_interaction_db(args, db)
    elif tool_name == "get_hcp_profile":
        return _get_hcp_profile_db(args, db)
    elif tool_name == "schedule_followup":
        return _schedule_followup_db(args, db)
    elif tool_name == "analyze_engagement":
        return _analyze_engagement_db(args, db)
    else:
        raise ValueError(f"Unknown tool: {tool_name}")


def _log_interaction_db(args: dict, db: Session) -> dict:
    notes = args.get("notes", "")
    
    # Use LLM to extract entities and summarize
    llm = ChatGroq(api_key=settings.GROQ_API_KEY, model="gemma2-9b-it", temperature=0)
    extraction_prompt = f"""Analyze this HCP interaction note and respond ONLY with JSON:
Notes: {notes}

Return JSON with these keys:
- summary: 2-3 sentence professional summary
- sentiment: "positive", "neutral", or "negative"
- products_mentioned: list of any drug/product names mentioned
- follow_up: suggested follow-up action or empty string

JSON only, no markdown."""
    
    try:
        response = llm.invoke(extraction_prompt)
        raw = response.content.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        extracted = json.loads(raw)
    except Exception:
        extracted = {
            "summary": notes[:200] + "..." if len(notes) > 200 else notes,
            "sentiment": "neutral",
            "products_mentioned": [],
            "follow_up": ""
        }

    products = args.get("products_discussed", "") or ", ".join(extracted.get("products_mentioned", []))
    
    interaction = Interaction(
        hcp_id=args.get("hcp_id"),
        interaction_type=args.get("interaction_type", "visit"),
        duration_minutes=args.get("duration_minutes", 30),
        notes=notes,
        ai_summary=extracted.get("summary", ""),
        products_discussed=products,
        sentiment=extracted.get("sentiment", "neutral"),
        follow_up_required=extracted.get("follow_up", ""),
    )
    db.add(interaction)
    db.commit()
    db.refresh(interaction)
    
    return {
        "status": "success",
        "interaction_id": interaction.id,
        "ai_summary": interaction.ai_summary,
        "sentiment": interaction.sentiment,
        "products_discussed": interaction.products_discussed,
        "follow_up_suggested": interaction.follow_up_required,
    }


def _edit_interaction_db(args: dict, db: Session) -> dict:
    interaction = db.query(Interaction).filter(Interaction.id == args.get("interaction_id")).first()
    if not interaction:
        return {"status": "error", "message": f"Interaction {args.get('interaction_id')} not found"}
    
    if args.get("notes"):
        interaction.notes = args["notes"]
    if args.get("products_discussed"):
        interaction.products_discussed = args["products_discussed"]
    if args.get("duration_minutes"):
        interaction.duration_minutes = args["duration_minutes"]
    if args.get("follow_up_required"):
        interaction.follow_up_required = args["follow_up_required"]
    
    # Re-summarize with LLM
    if args.get("notes"):
        llm = ChatGroq(api_key=settings.GROQ_API_KEY, model="gemma2-9b-it", temperature=0)
        try:
            resp = llm.invoke(f"Summarize this HCP interaction in 2 sentences: {interaction.notes}")
            interaction.ai_summary = resp.content.strip()
        except Exception:
            pass
    
    db.commit()
    return {"status": "success", "interaction_id": interaction.id, "ai_summary": interaction.ai_summary}


def _get_hcp_profile_db(args: dict, db: Session) -> dict:
    hcp = db.query(HCP).filter(HCP.id == args.get("hcp_id")).first()
    if not hcp:
        return {"status": "error", "message": "HCP not found"}
    
    interactions = db.query(Interaction).filter(Interaction.hcp_id == hcp.id).order_by(Interaction.date.desc()).limit(10).all()
    
    return {
        "status": "success",
        "hcp": {
            "id": hcp.id,
            "name": hcp.name,
            "specialty": hcp.specialty,
            "hospital": hcp.hospital,
            "email": hcp.email,
            "territory": hcp.territory,
            "engagement_score": hcp.engagement_score,
        },
        "total_interactions": len(interactions),
        "recent_interactions": [
            {
                "id": i.id,
                "type": i.interaction_type,
                "date": str(i.date),
                "sentiment": i.sentiment,
                "ai_summary": i.ai_summary,
            }
            for i in interactions
        ],
    }


def _schedule_followup_db(args: dict, db: Session) -> dict:
    followup = FollowUp(
        interaction_id=args.get("interaction_id"),
        hcp_id=args.get("hcp_id"),
        title=args.get("title"),
        description=args.get("description"),
        due_date=datetime.fromisoformat(args.get("due_date")),
    )
    db.add(followup)
    db.commit()
    db.refresh(followup)
    
    return {
        "status": "success",
        "followup_id": followup.id,
        "title": followup.title,
        "due_date": str(followup.due_date),
    }


def _analyze_engagement_db(args: dict, db: Session) -> dict:
    hcp = db.query(HCP).filter(HCP.id == args.get("hcp_id")).first()
    if not hcp:
        return {"status": "error", "message": "HCP not found"}
    
    interactions = db.query(Interaction).filter(Interaction.hcp_id == hcp.id).order_by(Interaction.date.desc()).all()
    if not interactions:
        return {"status": "success", "message": "No interactions found for this HCP", "recommendations": []}
    
    summaries = "\n".join([f"- [{i.date}] {i.sentiment}: {i.ai_summary}" for i in interactions[:10]])
    
    llm = ChatGroq(api_key=settings.GROQ_API_KEY, model="gemma2-9b-it", temperature=0.3)
    try:
        resp = llm.invoke(
            f"Analyze HCP {hcp.name}'s engagement based on these interactions:\n{summaries}\n\n"
            "Provide: 1) Sentiment trend, 2) Key topics of interest, 3) Top 3 recommended next actions. "
            "Be concise and actionable."
        )
        analysis = resp.content.strip()
    except Exception as e:
        analysis = "Analysis unavailable: " + str(e)
    
    sentiments = [i.sentiment for i in interactions]
    positive_pct = sentiments.count("positive") / len(sentiments) * 100 if sentiments else 0
    
    return {
        "status": "success",
        "hcp_name": hcp.name,
        "total_interactions": len(interactions),
        "sentiment_breakdown": {
            "positive": sentiments.count("positive"),
            "neutral": sentiments.count("neutral"),
            "negative": sentiments.count("negative"),
        },
        "positive_percentage": round(positive_pct, 1),
        "ai_analysis": analysis,
    }
