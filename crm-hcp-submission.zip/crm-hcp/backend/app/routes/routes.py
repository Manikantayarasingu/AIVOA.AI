from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.db.database import get_db
from app.models.models import HCP, Interaction, FollowUp
from app.agents.hcp_agent import create_agent
from langchain_core.messages import HumanMessage

router = APIRouter()


# ─── Pydantic Schemas ────────────────────────────────────────────────────────

class HCPCreate(BaseModel):
    name: str
    specialty: Optional[str] = None
    hospital: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    territory: Optional[str] = None


class InteractionCreate(BaseModel):
    hcp_id: int
    interaction_type: str = "visit"
    duration_minutes: int = 30
    products_discussed: str = ""
    notes: str
    follow_up_required: Optional[str] = None


class InteractionUpdate(BaseModel):
    notes: Optional[str] = None
    products_discussed: Optional[str] = None
    duration_minutes: Optional[int] = None
    follow_up_required: Optional[str] = None


class ChatMessage(BaseModel):
    message: str
    hcp_id: Optional[int] = None
    interaction_id: Optional[int] = None
    conversation_history: Optional[list] = []


# ─── HCP Endpoints ────────────────────────────────────────────────────────────

@router.get("/hcps")
def list_hcps(db: Session = Depends(get_db)):
    hcps = db.query(HCP).all()
    return [
        {
            "id": h.id,
            "name": h.name,
            "specialty": h.specialty,
            "hospital": h.hospital,
            "email": h.email,
            "territory": h.territory,
            "engagement_score": h.engagement_score,
            "interaction_count": len(h.interactions),
        }
        for h in hcps
    ]


@router.post("/hcps")
def create_hcp(hcp: HCPCreate, db: Session = Depends(get_db)):
    db_hcp = HCP(**hcp.model_dump())
    db.add(db_hcp)
    db.commit()
    db.refresh(db_hcp)
    return {"id": db_hcp.id, "name": db_hcp.name, "message": "HCP created successfully"}


@router.get("/hcps/{hcp_id}")
def get_hcp(hcp_id: int, db: Session = Depends(get_db)):
    hcp = db.query(HCP).filter(HCP.id == hcp_id).first()
    if not hcp:
        raise HTTPException(status_code=404, detail="HCP not found")
    
    interactions = db.query(Interaction).filter(Interaction.hcp_id == hcp_id).order_by(Interaction.date.desc()).all()
    return {
        "id": hcp.id,
        "name": hcp.name,
        "specialty": hcp.specialty,
        "hospital": hcp.hospital,
        "email": hcp.email,
        "phone": hcp.phone,
        "territory": hcp.territory,
        "engagement_score": hcp.engagement_score,
        "interactions": [
            {
                "id": i.id,
                "interaction_type": i.interaction_type,
                "date": str(i.date),
                "duration_minutes": i.duration_minutes,
                "products_discussed": i.products_discussed,
                "notes": i.notes,
                "ai_summary": i.ai_summary,
                "sentiment": i.sentiment,
                "follow_up_required": i.follow_up_required,
            }
            for i in interactions
        ],
    }


# ─── Interaction Endpoints ────────────────────────────────────────────────────

@router.get("/interactions")
def list_interactions(hcp_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(Interaction)
    if hcp_id:
        query = query.filter(Interaction.hcp_id == hcp_id)
    interactions = query.order_by(Interaction.date.desc()).all()
    return [
        {
            "id": i.id,
            "hcp_id": i.hcp_id,
            "hcp_name": i.hcp.name if i.hcp else "Unknown",
            "interaction_type": i.interaction_type,
            "date": str(i.date),
            "duration_minutes": i.duration_minutes,
            "products_discussed": i.products_discussed,
            "notes": i.notes,
            "ai_summary": i.ai_summary,
            "sentiment": i.sentiment,
            "follow_up_required": i.follow_up_required,
        }
        for i in interactions
    ]


@router.post("/interactions")
def create_interaction(data: InteractionCreate, db: Session = Depends(get_db)):
    """Direct form-based interaction logging (no AI agent)."""
    interaction = Interaction(
        hcp_id=data.hcp_id,
        interaction_type=data.interaction_type,
        duration_minutes=data.duration_minutes,
        products_discussed=data.products_discussed,
        notes=data.notes,
        follow_up_required=data.follow_up_required,
        ai_summary="",
        sentiment="neutral",
    )
    db.add(interaction)
    db.commit()
    db.refresh(interaction)
    return {"id": interaction.id, "message": "Interaction logged successfully"}


@router.put("/interactions/{interaction_id}")
def update_interaction(interaction_id: int, data: InteractionUpdate, db: Session = Depends(get_db)):
    interaction = db.query(Interaction).filter(Interaction.id == interaction_id).first()
    if not interaction:
        raise HTTPException(status_code=404, detail="Interaction not found")
    
    for field, value in data.model_dump(exclude_none=True).items():
        setattr(interaction, field, value)
    
    db.commit()
    return {"message": "Interaction updated successfully", "id": interaction_id}


@router.delete("/interactions/{interaction_id}")
def delete_interaction(interaction_id: int, db: Session = Depends(get_db)):
    interaction = db.query(Interaction).filter(Interaction.id == interaction_id).first()
    if not interaction:
        raise HTTPException(status_code=404, detail="Interaction not found")
    db.delete(interaction)
    db.commit()
    return {"message": "Interaction deleted"}


# ─── AI Agent Chat Endpoint ───────────────────────────────────────────────────

@router.post("/agent/chat")
async def agent_chat(payload: ChatMessage, db: Session = Depends(get_db)):
    """
    Conversational interface to the LangGraph agent.
    The agent can call any of the 5 tools based on the user's message.
    """
    try:
        agent = create_agent(db)
        
        # Reconstruct conversation history
        messages = []
        for msg in (payload.conversation_history or []):
            if msg.get("role") == "user":
                messages.append(HumanMessage(content=msg["content"]))
        
        messages.append(HumanMessage(content=payload.message))
        
        result = agent.invoke({
            "messages": messages,
            "hcp_id": payload.hcp_id,
            "interaction_id": payload.interaction_id,
        })
        
        # Extract the last AI message
        ai_messages = [m for m in result["messages"] if hasattr(m, "content") and not hasattr(m, "tool_call_id")]
        response_text = ai_messages[-1].content if ai_messages else "I processed your request."
        
        # Detect which tools were called
        tools_used = []
        for m in result["messages"]:
            if hasattr(m, "tool_calls") and m.tool_calls:
                for tc in m.tool_calls:
                    tools_used.append(tc["name"])
        
        return {
            "response": response_text,
            "tools_used": tools_used,
            "success": True,
        }
    except Exception as e:
        return {"response": f"Agent error: {str(e)}", "tools_used": [], "success": False}


# ─── Follow-up Endpoints ──────────────────────────────────────────────────────

@router.get("/followups")
def list_followups(hcp_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(FollowUp)
    if hcp_id:
        query = query.filter(FollowUp.hcp_id == hcp_id)
    followups = query.order_by(FollowUp.due_date).all()
    return [
        {
            "id": f.id,
            "hcp_id": f.hcp_id,
            "interaction_id": f.interaction_id,
            "title": f.title,
            "description": f.description,
            "due_date": str(f.due_date),
            "completed": f.completed,
        }
        for f in followups
    ]


# ─── Seed Data ────────────────────────────────────────────────────────────────

@router.post("/seed")
def seed_data(db: Session = Depends(get_db)):
    """Seed the database with sample HCPs for demo purposes."""
    sample_hcps = [
        HCP(name="Dr. Priya Sharma", specialty="Cardiology", hospital="Apollo Hospital", email="priya.sharma@apollo.in", territory="Bangalore South", engagement_score=8.5),
        HCP(name="Dr. Rajesh Kumar", specialty="Oncology", hospital="Manipal Hospital", email="rajesh.kumar@manipal.in", territory="Bangalore North", engagement_score=7.2),
        HCP(name="Dr. Anita Patel", specialty="Endocrinology", hospital="Fortis Hospital", email="anita.patel@fortis.in", territory="Bangalore East", engagement_score=6.8),
        HCP(name="Dr. Suresh Menon", specialty="Pulmonology", hospital="Columbia Asia", email="suresh.menon@columbia.in", territory="Bangalore West", engagement_score=9.1),
    ]
    for hcp in sample_hcps:
        existing = db.query(HCP).filter(HCP.email == hcp.email).first()
        if not existing:
            db.add(hcp)
    db.commit()
    return {"message": "Seed data added successfully"}
