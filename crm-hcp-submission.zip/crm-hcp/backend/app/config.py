from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    GROQ_API_KEY: str = "dummy_key"
    DATABASE_URL: str = "postgresql://crm_user:crm_password@localhost:5432/crm_hcp"
    SECRET_KEY: str = "supersecretkey123"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    class Config:
        env_file = ".env"


settings = Settings()
