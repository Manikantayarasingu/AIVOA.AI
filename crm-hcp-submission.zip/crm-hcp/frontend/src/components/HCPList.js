import React from 'react';

const SPECIALTY_ICONS = {
  Cardiology: '❤️',
  Oncology: '🔬',
  Endocrinology: '🧪',
  Pulmonology: '🫁',
  Neurology: '🧠',
};

export default function HCPList({ hcps, loading, onSelect }) {
  if (loading) return <div className="loading">Loading HCPs...</div>;

  return (
    <div className="hcp-list-page">
      <h2 className="page-title">Healthcare Professionals</h2>
      <p className="page-sub">Your assigned territory's HCP roster</p>
      <div className="hcp-grid">
        {hcps.map(hcp => (
          <div key={hcp.id} className="hcp-card" onClick={() => onSelect(hcp.id)}>
            <div className="hcp-card-header">
              <div className="hcp-card-avatar">
                {SPECIALTY_ICONS[hcp.specialty] || '👨‍⚕️'}
              </div>
              <div>
                <div className="hcp-card-name">{hcp.name}</div>
                <div className="hcp-card-spec">{hcp.specialty}</div>
              </div>
              <div className={`engagement-dot ${hcp.engagement_score >= 8 ? 'high' : hcp.engagement_score >= 6 ? 'med' : 'low'}`} />
            </div>
            <div className="hcp-card-body">
              <div className="hcp-detail">🏥 {hcp.hospital}</div>
              <div className="hcp-detail">📍 {hcp.territory}</div>
              <div className="hcp-stats">
                <div className="stat">
                  <span className="stat-val">{hcp.interaction_count || 0}</span>
                  <span className="stat-label">Interactions</span>
                </div>
                <div className="stat">
                  <span className="stat-val">{hcp.engagement_score?.toFixed(1) || '—'}</span>
                  <span className="stat-label">Score</span>
                </div>
              </div>
            </div>
            <button className="log-now-btn">Log Interaction →</button>
          </div>
        ))}
      </div>
    </div>
  );
}
