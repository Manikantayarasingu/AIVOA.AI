import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInteractions, deleteInteraction, updateInteraction } from '../store/interactionSlice';

const SENTIMENT_COLORS = { positive: '#22c55e', neutral: '#94a3b8', negative: '#ef4444' };
const SENTIMENT_ICONS = { positive: '😊', neutral: '😐', negative: '😟' };

export default function InteractionHistory({ hcpId, hcps, onSelectHCP }) {
  const dispatch = useDispatch();
  const { list: interactions, loading } = useSelector(s => s.interactions);
  const [editing, setEditing] = useState(null);
  const [editForm, setEditForm] = useState({});

  useEffect(() => {
    dispatch(fetchInteractions(hcpId));
  }, [dispatch, hcpId]);

  const handleDelete = async (id) => {
    if (window.confirm('Delete this interaction?')) {
      dispatch(deleteInteraction(id));
    }
  };

  const handleEdit = (interaction) => {
    setEditing(interaction.id);
    setEditForm({
      notes: interaction.notes,
      products_discussed: interaction.products_discussed,
      follow_up_required: interaction.follow_up_required || '',
    });
  };

  const handleSaveEdit = async (id) => {
    await dispatch(updateInteraction({ id, data: editForm }));
    setEditing(null);
    dispatch(fetchInteractions(hcpId));
  };

  if (loading) return <div className="loading">Loading interactions...</div>;

  return (
    <div className="history-page">
      <div className="history-header">
        <h2 className="page-title">Interaction History</h2>
        {hcpId && (
          <div className="filter-info">
            Filtered: {hcps.find(h => h.id === hcpId)?.name}
            <button className="clear-filter" onClick={() => onSelectHCP(null)}>✕ Clear</button>
          </div>
        )}
      </div>

      {interactions.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <h3>No interactions yet</h3>
          <p>Use the Log Interaction screen to capture your first HCP interaction.</p>
        </div>
      )}

      <div className="interaction-list">
        {interactions.map(interaction => (
          <div key={interaction.id} className="interaction-card">
            {editing === interaction.id ? (
              <div className="edit-form">
                <h4>Editing Interaction #{interaction.id}</h4>
                <textarea
                  value={editForm.notes}
                  onChange={e => setEditForm(prev => ({ ...prev, notes: e.target.value }))}
                  rows={4}
                  className="notes-textarea"
                  placeholder="Notes..."
                />
                <input
                  type="text"
                  value={editForm.products_discussed}
                  onChange={e => setEditForm(prev => ({ ...prev, products_discussed: e.target.value }))}
                  className="text-input"
                  placeholder="Products discussed..."
                />
                <input
                  type="text"
                  value={editForm.follow_up_required}
                  onChange={e => setEditForm(prev => ({ ...prev, follow_up_required: e.target.value }))}
                  className="text-input"
                  placeholder="Follow-up required..."
                />
                <div className="edit-actions">
                  <button className="save-btn" onClick={() => handleSaveEdit(interaction.id)}>Save</button>
                  <button className="cancel-btn" onClick={() => setEditing(null)}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div className="card-header">
                  <div className="card-left">
                    <span className="interaction-type-badge">{interaction.interaction_type}</span>
                    <span className="interaction-date">
                      {new Date(interaction.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="card-right">
                    <span
                      className="sentiment-badge"
                      style={{ color: SENTIMENT_COLORS[interaction.sentiment] }}
                    >
                      {SENTIMENT_ICONS[interaction.sentiment]} {interaction.sentiment}
                    </span>
                    <span className="duration-badge">⏱ {interaction.duration_minutes}m</span>
                  </div>
                </div>

                <div className="card-hcp">
                  <strong>{interaction.hcp_name}</strong>
                </div>

                {interaction.ai_summary && (
                  <div className="ai-summary">
                    <span className="ai-label">🤖 AI Summary</span>
                    <p>{interaction.ai_summary}</p>
                  </div>
                )}

                {interaction.products_discussed && (
                  <div className="products-row">
                    {interaction.products_discussed.split(',').map(p => p.trim()).filter(Boolean).map(p => (
                      <span key={p} className="product-tag">{p}</span>
                    ))}
                  </div>
                )}

                {interaction.follow_up_required && (
                  <div className="followup-row">
                    📅 <em>{interaction.follow_up_required}</em>
                  </div>
                )}

                <div className="card-actions">
                  <button className="edit-btn" onClick={() => handleEdit(interaction)}>✏️ Edit</button>
                  <button className="delete-btn" onClick={() => handleDelete(interaction.id)}>🗑 Delete</button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
