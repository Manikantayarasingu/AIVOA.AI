import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createInteraction } from '../store/interactionSlice';

const INTERACTION_TYPES = ['visit', 'call', 'email', 'conference', 'webinar'];
const PRODUCTS = ['CardioPlus', 'OncoClear', 'DiabeCare', 'RespirAid', 'NeuroShield', 'ImmunoBoost'];

const initialForm = {
  interaction_type: 'visit',
  duration_minutes: 30,
  products_discussed: [],
  notes: '',
  follow_up_required: '',
};

export default function FormLogger({ hcpId, hcps }) {
  const dispatch = useDispatch();
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState(null); // 'saving' | 'success' | 'error'

  const hcp = hcps.find(h => h.id === hcpId);

  const handleProductToggle = (product) => {
    setForm(prev => ({
      ...prev,
      products_discussed: prev.products_discussed.includes(product)
        ? prev.products_discussed.filter(p => p !== product)
        : [...prev.products_discussed, product],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!hcpId) { alert('Please select an HCP first'); return; }
    
    setStatus('saving');
    try {
      await dispatch(createInteraction({
        ...form,
        hcp_id: hcpId,
        products_discussed: form.products_discussed.join(', '),
      })).unwrap();
      setStatus('success');
      setForm(initialForm);
      setTimeout(() => setStatus(null), 3000);
    } catch (err) {
      setStatus('error');
    }
  };

  return (
    <form className="form-logger" onSubmit={handleSubmit}>
      {/* HCP Info Banner */}
      {hcp && (
        <div className="hcp-banner">
          <div className="hcp-avatar">{hcp.name.charAt(0)}</div>
          <div>
            <div className="hcp-banner-name">{hcp.name}</div>
            <div className="hcp-banner-meta">{hcp.specialty} · {hcp.hospital}</div>
          </div>
          <div className="hcp-score">
            <div className="score-value">{hcp.engagement_score?.toFixed(1) || '—'}</div>
            <div className="score-label">Engagement</div>
          </div>
        </div>
      )}

      <div className="form-grid">
        {/* Interaction Type */}
        <div className="form-field">
          <label>Interaction Type</label>
          <div className="type-pills">
            {INTERACTION_TYPES.map(t => (
              <button
                key={t}
                type="button"
                className={`pill ${form.interaction_type === t ? 'active' : ''}`}
                onClick={() => setForm(prev => ({ ...prev, interaction_type: t }))}
              >
                {t === 'visit' ? '🏥' : t === 'call' ? '📞' : t === 'email' ? '📧' : t === 'conference' ? '🎤' : '💻'} {t}
              </button>
            ))}
          </div>
        </div>

        {/* Duration */}
        <div className="form-field">
          <label>Duration: <strong>{form.duration_minutes} min</strong></label>
          <input
            type="range"
            min="5"
            max="120"
            step="5"
            value={form.duration_minutes}
            onChange={(e) => setForm(prev => ({ ...prev, duration_minutes: Number(e.target.value) }))}
            className="range-slider"
          />
          <div className="range-labels"><span>5m</span><span>1h</span><span>2h</span></div>
        </div>

        {/* Products */}
        <div className="form-field full-width">
          <label>Products Discussed</label>
          <div className="product-chips">
            {PRODUCTS.map(p => (
              <button
                key={p}
                type="button"
                className={`chip ${form.products_discussed.includes(p) ? 'active' : ''}`}
                onClick={() => handleProductToggle(p)}
              >
                {form.products_discussed.includes(p) ? '✓ ' : ''}{p}
              </button>
            ))}
          </div>
        </div>

        {/* Notes */}
        <div className="form-field full-width">
          <label>Interaction Notes <span className="required">*</span></label>
          <textarea
            value={form.notes}
            onChange={(e) => setForm(prev => ({ ...prev, notes: e.target.value }))}
            placeholder="Describe the interaction — what was discussed, HCP's feedback, concerns raised, samples provided..."
            rows={5}
            required
            className="notes-textarea"
          />
          <div className="char-count">{form.notes.length} chars</div>
        </div>

        {/* Follow-up */}
        <div className="form-field full-width">
          <label>Follow-up Action</label>
          <input
            type="text"
            value={form.follow_up_required}
            onChange={(e) => setForm(prev => ({ ...prev, follow_up_required: e.target.value }))}
            placeholder="e.g., Send clinical data for CardioPlus, Schedule CME event..."
            className="text-input"
          />
        </div>
      </div>

      {/* Submit */}
      <div className="form-actions">
        {status === 'success' && (
          <div className="status-badge success">✅ Interaction logged successfully!</div>
        )}
        {status === 'error' && (
          <div className="status-badge error">❌ Failed to save. Please try again.</div>
        )}
        <button
          type="submit"
          className="submit-btn"
          disabled={status === 'saving'}
        >
          {status === 'saving' ? '⏳ Saving...' : '💾 Log Interaction'}
        </button>
      </div>
    </form>
  );
}
