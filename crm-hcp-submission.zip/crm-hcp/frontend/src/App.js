import React, { useEffect, useState } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { store } from './store/store';
import { fetchHCPs, seedData } from './store/hcpSlice';
import LogInteractionScreen from './pages/LogInteractionScreen';
import HCPList from './components/HCPList';
import InteractionHistory from './components/InteractionHistory';
import './App.css';

function AppContent() {
  const dispatch = useDispatch();
  const { list: hcps, loading } = useSelector(s => s.hcps);
  const [view, setView] = useState('log'); // 'log' | 'history' | 'hcps'
  const [selectedHCPId, setSelectedHCPId] = useState(null);
  const [seeded, setSeeded] = useState(false);

  useEffect(() => {
    dispatch(fetchHCPs());
  }, [dispatch]);

  const handleSeed = async () => {
    await dispatch(seedData());
    await dispatch(fetchHCPs());
    setSeeded(true);
  };

  return (
    <div className="app">
      {/* Top Nav */}
      <header className="app-header">
        <div className="header-brand">
          <div className="brand-icon">⚕</div>
          <div>
            <div className="brand-name">MedCRM</div>
            <div className="brand-sub">HCP Intelligence Platform</div>
          </div>
        </div>
        <nav className="header-nav">
          <button className={`nav-btn ${view === 'log' ? 'active' : ''}`} onClick={() => setView('log')}>
            <span>📝</span> Log Interaction
          </button>
          <button className={`nav-btn ${view === 'history' ? 'active' : ''}`} onClick={() => setView('history')}>
            <span>📋</span> History
          </button>
          <button className={`nav-btn ${view === 'hcps' ? 'active' : ''}`} onClick={() => setView('hcps')}>
            <span>👨‍⚕️</span> HCPs
          </button>
        </nav>
        <div className="header-actions">
          {!seeded && hcps.length === 0 && (
            <button className="seed-btn" onClick={handleSeed}>Load Demo Data</button>
          )}
          <div className="rep-badge">Rep: John Doe</div>
        </div>
      </header>

      {/* Main Content */}
      <main className="app-main">
        {view === 'log' && (
          <LogInteractionScreen
            hcps={hcps}
            selectedHCPId={selectedHCPId}
            onSelectHCP={setSelectedHCPId}
          />
        )}
        {view === 'history' && <InteractionHistory hcpId={selectedHCPId} hcps={hcps} onSelectHCP={setSelectedHCPId} />}
        {view === 'hcps' && <HCPList hcps={hcps} loading={loading} onSelect={(id) => { setSelectedHCPId(id); setView('log'); }} />}
      </main>
    </div>
  );
}

function App() {
  return (
    <Provider store={store}>
      <AppContent />
    </Provider>
  );
}

export default App;
