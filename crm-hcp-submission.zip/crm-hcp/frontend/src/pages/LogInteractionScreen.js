import React, { useState } from 'react';
import FormLogger from '../components/FormLogger';
import ChatLogger from '../components/ChatLogger';

const TABS = [
  { id: 'form', label: '📋 Form', desc: 'Structured entry' },
  { id: 'chat', label: '🤖 AI Chat', desc: 'Conversational' },
];

export default function LogInteractionScreen({ hcps, selectedHCPId, onSelectHCP }) {
  const [activeTab, setActiveTab] = useState('form');

  return (
    <div className="log-screen">
      <div className="log-header">
        <div>
          <h1 className="log-title">Log HCP Interaction</h1>
          <p className="log-subtitle">
            Choose your preferred method to capture today's interaction
          </p>
        </div>
        <div className="hcp-select-wrap">
          <label>Select HCP</label>
          <select
            value={selectedHCPId || ''}
            onChange={(e) => onSelectHCP(e.target.value ? Number(e.target.value) : null)}
            className="hcp-select"
          >
            <option value="">-- Select Healthcare Professional --</option>
            {hcps.map(h => (
              <option key={h.id} value={h.id}>
                {h.name} · {h.specialty}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="tab-bar">
        {TABS.map(tab => (
          <button
            key={tab.id}
            className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="tab-label">{tab.label}</span>
            <span className="tab-desc">{tab.desc}</span>
          </button>
        ))}
      </div>

      {/* Active Panel */}
      <div className="log-panel">
        {activeTab === 'form' && (
          <FormLogger hcpId={selectedHCPId} hcps={hcps} />
        )}
        {activeTab === 'chat' && (
          <ChatLogger hcpId={selectedHCPId} hcps={hcps} />
        )}
      </div>
    </div>
  );
}
