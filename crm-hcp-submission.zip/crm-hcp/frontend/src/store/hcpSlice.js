import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../api/client';

export const fetchHCPs = createAsyncThunk('hcps/fetchAll', async () => {
  const res = await api.get('/hcps');
  return res.data;
});

export const fetchHCPById = createAsyncThunk('hcps/fetchById', async (id) => {
  const res = await api.get(`/hcps/${id}`);
  return res.data;
});

export const createHCP = createAsyncThunk('hcps/create', async (data) => {
  const res = await api.post('/hcps', data);
  return res.data;
});

export const seedData = createAsyncThunk('hcps/seed', async () => {
  const res = await api.post('/seed');
  return res.data;
});

const hcpSlice = createSlice({
  name: 'hcps',
  initialState: {
    list: [],
    selected: null,
    loading: false,
    error: null,
  },
  reducers: {
    selectHCP: (state, action) => {
      state.selected = action.payload;
    },
    clearSelected: (state) => {
      state.selected = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHCPs.pending, (state) => { state.loading = true; })
      .addCase(fetchHCPs.fulfilled, (state, action) => { state.loading = false; state.list = action.payload; })
      .addCase(fetchHCPs.rejected, (state, action) => { state.loading = false; state.error = action.error.message; })
      .addCase(fetchHCPById.fulfilled, (state, action) => { state.selected = action.payload; });
  },
});

export const { selectHCP, clearSelected } = hcpSlice.actions;
export default hcpSlice.reducer;
