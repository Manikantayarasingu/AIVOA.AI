import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../api/client';

export const sendAgentMessage = createAsyncThunk('agent/chat', async (payload) => {
  const res = await api.post('/agent/chat', payload);
  return res.data;
});

const agentSlice = createSlice({
  name: 'agent',
  initialState: {
    messages: [],
    loading: false,
    error: null,
    toolsUsed: [],
  },
  reducers: {
    addUserMessage: (state, action) => {
      state.messages.push({ role: 'user', content: action.payload, timestamp: new Date().toISOString() });
    },
    clearConversation: (state) => {
      state.messages = [];
      state.toolsUsed = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendAgentMessage.pending, (state) => { state.loading = true; })
      .addCase(sendAgentMessage.fulfilled, (state, action) => {
        state.loading = false;
        state.messages.push({
          role: 'assistant',
          content: action.payload.response,
          toolsUsed: action.payload.tools_used,
          timestamp: new Date().toISOString(),
        });
        if (action.payload.tools_used?.length) {
          state.toolsUsed = [...new Set([...state.toolsUsed, ...action.payload.tools_used])];
        }
      })
      .addCase(sendAgentMessage.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
        state.messages.push({ role: 'assistant', content: 'Error: ' + action.error.message, timestamp: new Date().toISOString() });
      });
  },
});

export const { addUserMessage, clearConversation } = agentSlice.actions;
export default agentSlice.reducer;
