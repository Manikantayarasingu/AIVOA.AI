import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../api/client';

export const fetchInteractions = createAsyncThunk('interactions/fetchAll', async (hcpId) => {
  const url = hcpId ? `/interactions?hcp_id=${hcpId}` : '/interactions';
  const res = await api.get(url);
  return res.data;
});

export const createInteraction = createAsyncThunk('interactions/create', async (data) => {
  const res = await api.post('/interactions', data);
  return res.data;
});

export const updateInteraction = createAsyncThunk('interactions/update', async ({ id, data }) => {
  const res = await api.put(`/interactions/${id}`, data);
  return { id, ...res.data };
});

export const deleteInteraction = createAsyncThunk('interactions/delete', async (id) => {
  await api.delete(`/interactions/${id}`);
  return id;
});

const interactionSlice = createSlice({
  name: 'interactions',
  initialState: {
    list: [],
    loading: false,
    error: null,
    lastCreated: null,
  },
  reducers: {
    clearLastCreated: (state) => { state.lastCreated = null; },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchInteractions.pending, (state) => { state.loading = true; })
      .addCase(fetchInteractions.fulfilled, (state, action) => { state.loading = false; state.list = action.payload; })
      .addCase(fetchInteractions.rejected, (state, action) => { state.loading = false; state.error = action.error.message; })
      .addCase(createInteraction.fulfilled, (state, action) => { state.lastCreated = action.payload; })
      .addCase(deleteInteraction.fulfilled, (state, action) => {
        state.list = state.list.filter(i => i.id !== action.payload);
      });
  },
});

export const { clearLastCreated } = interactionSlice.actions;
export default interactionSlice.reducer;
