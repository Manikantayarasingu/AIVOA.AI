import { configureStore } from '@reduxjs/toolkit';
import hcpReducer from './hcpSlice';
import interactionReducer from './interactionSlice';
import agentReducer from './agentSlice';

export const store = configureStore({
  reducer: {
    hcps: hcpReducer,
    interactions: interactionReducer,
    agent: agentReducer,
  },
});

export default store;
